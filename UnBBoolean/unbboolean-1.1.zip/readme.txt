UNBBOOLEAN
by Danilo Balby (danbalby@yahoo.com)
Homepage: http://unbboolean.sourceforge.net/

INTRODUCTION:
UnBBoolean is a 3D modeling tool to apply boolean set operations on primitive solids. 
It's based on Constructive Solid Geometry concepts. Java and Java3D are required.

COMPILED WITH:
Java Runtime Environment (JRE) v6 and Java3D v1.5.2

To run the application, execute run.bat file. If it doesn't work, check if there is a 
JRE and Java3D installed on your computer. In affirmative case, try to modify run.bat 
file to execute directly the java executable file
(e.g., "C:\Program Files\Java\jre6\bin\java" -cp ".\bin" unbboolean.UnBBooleanMain).